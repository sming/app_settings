# Save Highlighted Text

When the .ahk script is initialized, it creates the highlights folder in the Desktop.
Then it copies over `md-page.js`. Wherever you run `saveHighlightedText.ahk`, also have
`md-page.js` in the same folder.
