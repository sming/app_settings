# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

## ---(Fri May 24 10:15:39 2019)---
razor
cd ~/src
cd razor
cd *dbq*
ls
cd razor-middleware-dbquery-service
?
r ?
pwd
r ./src/main.py 
cd src
r main.py
r main
%run main.py
cd ..
%run ./src/main.py
%set_env DB_CONN postgresql+psycopg2://postgres:toiletTourist@localhost:5432
%run ./src/main.py
%run -d ./src/main.py