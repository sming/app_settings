# This is targeted only at Ubuntu for now (and even then, might be a bit buggy, please feel free to submit issues for it)
# It installs enough to run torch, nn, clnn, cltorch; but no gui components, ie no qt, no itorch, etc

sudo apt-get install -y wget git gcc g++ cmake cmake-curses-gui libffi-dev libblas-dev liblapack-dev gfortran libreadline-dev libprotobuf-dev protobuf-compiler libpng12-dev

