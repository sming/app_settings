Only DB service runs Gunicorn. Why?
Default service is much heavier

From DB Service README
-----------------------------
This is a separate service since razor-middleware-default-service —which is the current default UI service— works on Standard Google AppEngine Python 2 environmennt which doesn't support Google Cloud SQL connections.

Until the razor-middleware-default-service is (if possible) converted into Flexible Python 3 (3.7 only supported for Cloud SQL) environment (which has a difficulty since Flexible Environment has problems connecting to Google DataStore this time), query functions against Google Cloud SQL will be served within this service.
-----------------------------

So it would seem to be a case of :
1. upgrade default service to "Flexible python 3" <-- NOPE: db service doesn't need DB any more so no need.
2. move DB calls in there.

razor_memoizer.py contains a bunch of Redis stuff.
openapi.yaml? will need refactoring-merging.

TODO: find out which endpoints are still in use and add the remaining ones to a "kill list". 

OK, HERE'S A LIST OF THE ENDPOINTS IN USE FROM client (remember to get the default->db service ones as well)
-----------------------------
RECOMMENDATION_URL      `${SERVICE_BASE}/grant/recommend_similar`;
AUTOCOMPLETE_URL        `${SERVICE_BASE}/autocomplete_algolia`;
RADAR_CHART_BASE_URL    `${SERVICE_DB_BASE}/radar_chart`;
RADAR_REPORT_BASE_URL   `${SERVICE_DB_BASE}/radar_report`;


WAIT: there's no need since we're not using the google cloud functions at all.
SO: find out exactly what the DB Service is doing now.


:bulb: *If you are using the `flow-for-vscode` plugin, make sure to disable the `flowtype-errors/show-errors` eslint rule in the `.eslintrc` by setting it to `0`*

