# LOGIN FLOW

## JS
Pass the entered credentials to the python backend's /login endpoint. If successful, gets an authToken
and a refreshToken which are stored in Redux/Flux.

| Source File | Function |
| ------ | ------ |
|Home.js| :           onKeyDown -> |
||                    this.attemptLogin -> |
|homepage.js|       login ->|
||fetch https://razor-dot-mjf-deliverable.appspot.com/login|

--> *OVER THE WIRE TO* -->

## PYTHON
| Source File | Function |
| ------ | ------ |
|main.py|:            post_login [look in request's form, json and parameters for client_id and client_secret] ->|
|authenticator.py|   login -> firebase_auth.create_custom_token
||                          -> get_refresh_token [gets a refresh token & expiresIn, using the auth token]|
||```return jsonify({   	"access_token": id_token,   	"token_type": "bearer",   	"expires_in": expiresIn,   	"refresh_token": refresh_token, "search_token": search_token,   	"scope": "MJF.enduser"   }```)
