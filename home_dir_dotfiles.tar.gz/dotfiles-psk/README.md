# dotfiles_psk
my actual .x files, not the one I forked
